# Author: Xinshuo Weng
# email: xinshuo.weng@gmail.com

from xinshuo_math import generate_sphere

pts_3d = [0, 0, 0]
radius = 1

pts_shpere = generate_sphere(pts_3d, radius)
print(pts_shpere)