# Author: Xinshuo Weng
# email: xinshuo.weng@gmail.com

from .configuration import prepare_seed